// Add your verified contact details before launch. Do not publish placeholder contact details.
window.AI_VISION_CONTACT = { email: '', whatsapp: '' };
